/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mycompany.maven_exercise;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Jan Berg
 * 
 * Logic class is as a interface between UI and Database, so it takes the information
 * from the user inputs and sends those to database. 
 */
public class Logic {
    
    //Define DbHandler
    DbHandler db;
    
    public Logic(){
        try {
           //Instantiate new DbHandler to be used for handling database queries
           db = new DbHandler();
           
           //Calls DbHandler.update to create a table called entries
           db.update("CREATE TABLE entries ( firstname VARCHAR(20), lastname VARCHAR(20), description VARCHAR(200), gender VARCHAR(10))");
        } catch (Exception ex) {
            Logger.getLogger(Logic.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void setInformation(ArrayList<String> info){
        
        try {
            
            /*Replace special characters from the string to be sent to database.
            Inputs are validated, but this phase is done to further enhance security
            (in case of sql injection etc).
            */
          
            for(int i = 0;i < info.size(); i++){
                info.set(i, info.get(i).replaceAll("[-+.^:,]",""));                
            }
            
            //Call update to insert data in database
            db.update(info);
                   
             
             
        } catch (SQLException ex) {
            Logger.getLogger(Logic.class.getName()).log(Level.SEVERE, null, ex);
            
        }
    }
    
    public ArrayList<String> getInformation(){
        ArrayList<String> info = new ArrayList<String>();
        
        try {
            
            //Just a query call to select everything from table entries
            info = db.query("SELECT * FROM entries");
            
            return info;
        } catch (SQLException ex) {
            Logger.getLogger(Logic.class.getName()).log(Level.SEVERE, null, ex);
            info.add("Database error");
            return info;
        }
        
        
        
    }
    
    
    
}
