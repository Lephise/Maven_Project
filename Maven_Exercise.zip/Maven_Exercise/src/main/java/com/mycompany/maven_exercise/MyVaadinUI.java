package com.mycompany.maven_exercise;

import javax.servlet.annotation.WebServlet;

import com.vaadin.annotations.Theme;
import com.vaadin.annotations.VaadinServletConfiguration;
import com.vaadin.data.validator.RegexpValidator;
import com.vaadin.server.VaadinRequest;
import com.vaadin.server.VaadinServlet;
import com.vaadin.shared.ui.label.ContentMode;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.Component;
import com.vaadin.ui.Label;
import com.vaadin.ui.TextArea;
import com.vaadin.ui.TextField;
import com.vaadin.ui.UI;
import com.vaadin.ui.VerticalLayout;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@Theme("mytheme")
@SuppressWarnings("serial")

public class MyVaadinUI extends UI {

    @WebServlet(value = "/*", asyncSupported = true)
    @VaadinServletConfiguration(productionMode = false, ui = MyVaadinUI.class, widgetset = "com.mycompany.maven_exercise.AppWidgetSet")
    public static class Servlet extends VaadinServlet {
    }

    @Override
    protected void init(VaadinRequest request) {
        final VerticalLayout layout = new VerticalLayout();
        layout.setMargin(true);
        setContent(layout);
        
        //Create new instance of Logic class
        final Logic lg = new Logic();

        //Regex validator string to be used to validate text inputs
        RegexpValidator regex = new RegexpValidator("[A-ZÖÄÅa-zöäå]{2,20}", "Can only contain letters}");
        
        //Label to just show some results after submitting
        final Label lbl = new Label("", Label.CONTENT_XHTML);

        /*Input fields; First and lastname are required and validated by the regex string
        defined before. Text Area for description and combo box for gender selection
        */
        final TextField firstname = new TextField("First Name");
        firstname.addValidator(regex);
        firstname.setRequired(true);
        layout.addComponent(firstname);

        final TextField lastname = new TextField("Last Name");
        lastname.setRequired(true);
        lastname.addValidator(regex);
        layout.addComponent(lastname);

        final TextArea description = new TextArea("Why are you applying for this job?");
        description.setHeight("100");
        description.setWidth("300");
        layout.addComponent(description);

        final ComboBox gender = new ComboBox("Gender");
        gender.setNullSelectionAllowed(false);

        gender.addItem("Male");
        gender.addItem("Female");

        gender.setValue("Male");

        layout.addComponent(gender);

        /*
        Button and event handler for click event. Creates a list of inputs (if the inputs
        are valid) and sends the list to "setInformation" function of Logic class. 
        
        getInformation fetches results from database and shows the last entry in label.
        */
        Button button = new Button("Submit");
        button.addClickListener(new Button.ClickListener() {
            public void buttonClick(ClickEvent event) {
                if (firstname.isValid() && lastname.isValid()) {
                    ArrayList<String> info = new ArrayList<String>();
                    info.add(firstname.getValue());
                    info.add(lastname.getValue());
                    info.add(description.getValue());
                    info.add((String) gender.getValue());

                    lg.setInformation(info);

                    info = lg.getInformation();
                    lbl.setValue("<pre>Successfully added following info: \r Firstname: "+ info.get(0) + "\r Lastname: "+ info.get(1) + "\r Why are you applying for this job?: "+info.get(2) + "\r Gender: " +info.get(3) + "</pre>");
                         
                    
                }
            }
        });

        layout.addComponent(button);
        
        layout.addComponent(lbl);
    }

}
