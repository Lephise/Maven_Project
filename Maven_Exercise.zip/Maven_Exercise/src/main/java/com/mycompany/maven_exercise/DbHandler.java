/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.maven_exercise;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Jan_Berg
 * 
 * Class for handling database queries
 */
public class DbHandler {

    //Define connection variable
    Connection con;

    public DbHandler() throws Exception {

        //Get driver for hsqldb
        Class.forName("org.hsqldb.jdbc.JDBCDriver");

        //Defines new connection. In this case its a in-memory hsqldb connection
        con = DriverManager.getConnection("jdbc:hsqldb:mem:memdb", "SA", "");

    }

    public synchronized ArrayList<String> query(String expression) throws SQLException {

        Statement st = null;
        ResultSet rs = null;
        ArrayList<String> info = new ArrayList<String>();
        
        //Create new statement, scroll insensitive just so we can return only the last row
        st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);         // statement objects can be reused with

        rs = st.executeQuery("SELECT * FROM entries");
        
        //Set the pointer to the last row (the newest one) in result set.
        rs.last();
        int i = 1;

        //Loop through the current result set row and populate the list.
        while (i <= rs.getMetaData().getColumnCount()) {
            info.add(rs.getString(i++));

        }

        st.close();
        return info;

    }

    //Function for single string update query
    public synchronized void update(String query) throws SQLException {

        Statement st = null;

        st = con.createStatement();

        int i = st.executeUpdate(query);

        st.close();
    }

    /*Overload for update function to handle String typed arraylists, this is for
    inserting user input into database.
    */
    public synchronized void update(ArrayList<String> info) throws SQLException {

        Statement st = null;

        //String is created by formatting the string, should enhance the security of the program a bit.
        String query = String.format("INSERT INTO entries(firstname,lastname, description, gender) VALUES('%s', '%s', '%s', '%s')", info.get(0), info.get(1), info.get(2), info.get(3));

        st = con.createStatement();

        int i = st.executeUpdate(query);

        st.close();
    }

}
